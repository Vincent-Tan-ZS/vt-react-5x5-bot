export enum Direction {
    North,
    East,
    South,
    West
};